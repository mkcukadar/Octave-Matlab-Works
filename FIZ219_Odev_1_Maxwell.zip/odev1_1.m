










#----------------------------------------------GRUP : MAXWELL Hayati Tozlu, Mert Kaan Cukadar, Mehmet Deniz Mulazim ------------------------------------
clear;
# Bir dizi tanimliyoruz birden baslayip yapilacak olan bolmede, 2 tum cift sayilara bolunulebilme ozelligi dolayisi ile dizinin icine ataniyor.
dizi = [2];
#Asal sayi olup olmadigi sinanan sayinin sinanmasi icin kendisinden bir onceki sayiya kadar her degeri bolen olarak atayip. Asalligi sinanan sayi, bolen olarak atanan degerlere sirayla bolunur.
# sorguya alinacak olan aralik tanimlanir.
for i = 3:1:300
# asal sayiya bolunecek sayilar tanimlanir deneme yapilmasi icin for dongusune alinir.
    for k = 2:1:i-1
    div = mod(i,k);
#eger sayinin modu (bolumunden kalani) 0 ise dongu bastan baslar.
        if (div == 0);
            break
        endif
    endfor
# eger sayinin modu 0 a esit degil ise bolunen sayi diziye yazdirilir.
    if (div != 0)
    dizi = [dizi, i];
    endif
endfor
disp("asal sayilar: ")
disp(dizi)

#grup maxwell
#--------------------------------------------------------GRUP : MAXWELL ------------------------------------
