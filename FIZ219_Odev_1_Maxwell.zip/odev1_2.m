
#----------------------------------------------GRUP : MAXWELL Hayati Tozlu, Mert Kaan Cukadar, Mehmet Deniz Mulazim ------------------------------------
#-------------------------------------------------------------------------------soru_2_cozumu--------------------------------------------------------------

clear;
#x0 = 0, adim_boyu = 1E-4, olarak tanimla. ---------------TANIMLANDI------------------
x0 = 0;
adim_boyu = 1E-4; 
x1=0;
#x1 = x0 + adim_boyu olarak tanimla. ---------------TANIMLANDI------------------ Denklemler hesaplama dongusune sokuldu.--------------------
for i = 0:1E-4:100
x1 = x0 + adim_boyu;
a = 3*(x0)^2-7*(x0)+4;
b = 3*(x1)^2 - 7*(x1) + 4;
#--------------------------------------------------- a ve b denklemlerinin sonuclari kendi aralarinda karsilastirildi--------------------
if (a > 0 & b > 0) || (a < 0 & b < 0)
    x0 = x1;
    a = b;
endif
#------------------------------------------------------ayni isaretli degillerse x degerleri toplanip ikiye bolundu kok bulundu.-------------------
  if ((a < 0) & (b > 0)) ||((a > 0) & (b < 0))
        kok = (x0+x1) / 2;
        break
      endif
  
endfor 
# --------------------------------------------------------------dongu aramaya ilk bulunan kokten baslandi ve yaklasim degeri epsilon dan verildi-----------------------------
kok1=kok;
for i = 0:1E-4:10
  x1=kok1+ adim_boyu;
  c = 3*(kok1)^2-7*(kok1)+4;
  d = 3*(x1)^2 - 7*(x1) + 4;
  
  if (c > 0 & d > 0) || (c < 0 & d < 0)
    kok1 = x1;
    c = d;
endif

if ((c < eps) & (d > eps)) || ((c > eps) & (d> eps))
        kok2 = (kok1+x1) / 2;
        break
      endif

endfor
disp("1. kok ve 2.kok sunlardir:")
kok
kok2
disp("bonus cozumleri icin space tusuna basiniz")
pause





#---------------------------------------------------Bonus_3_Çozumleri--------------------------------------------------------------------








disp("x**2 -4x +5 denkleminin koku var midir ogrenmek icin space e basiniz:")

pause

clear;
adim_boyu = 1E-4;
x0 = 0;
x1 = 0;
#x1 = x0 + adim_boyu olarak tanimla. ---------------TANIMLANDI------------------ Denklemler hesaplama dongusune sokuldu.--------------------
for i = 0:1E-4:100
fx0 = x0**2 - 4*x0 + 5;
fx1 = x1**2 - 4*x1 + 5;
x0 = x1;
x1 = x0 + adim_boyu;
fx1;
fx0;
#-------------------------------------------------Eger denklemler 0 a esit olurlarsa x eksenini keserler koku vardir kosul cumlesi kuruldu---------------------
if(fx1 == 0 || fx0 == 0);
disp("kokunuz vardir bilginize...")
disp("bizden bir kiyak kokunuz de budur: ")
disp(x0)
break
endif
#--------------parabol her denklem icin gozlemlendi eger sifiri kesmeden bir denklem digerinden buyuk oluyorsa kok yoktur kosul cumlesi kuruldu-----------------
if fx1 > fx0;
disp("kokunuz yok kb...")
break
endif

endfor

disp("x**2-4x +4 icin kok kontrolu istiyorsaniz space e basin:")

pause







#------------------------------------------------------------------------------Bonus_2_nin cozumu ---------------------------------------------------------------






clear;
adim_boyu = 1E-4;
x0 = 0;
x1 = 0;

for i = 0:1E-4:100
fx0 = x0**2 - 4*x0 + 4;
fx1 = x1**2 - 4*x1 + 4;
x0 = x1;
x1 = x0 + adim_boyu;
fx1;
fx0;
#-------------------------------------------------Eger denklemler 0 a esit olurlarsa x eksenini keserler koku vardir kosul cumlesi kuruldu---------------------
if(fx1 == 0 || fx0 == 0);
disp("kokunuz vardir bilginize...")
disp("bizden bir kiyak kokunuz budur: ")
disp(x0)
break
endif
#--------------parabol her denklem icin gozlemlendi eger sifiri kesmeden bir denklem digerinden buyuk oluyorsa kok yoktur kosul cumlesi kuruldu-----------------
if fx1 > fx0;
disp("kokunuz yok kb...")
break
endif

endfor


#--------------------------------------------------------GRUP : MAXWELL ------------------------------------













