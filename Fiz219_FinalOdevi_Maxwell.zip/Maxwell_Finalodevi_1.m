clear
clc
#Grup Adi:Maxwell
#Grup Uyeleri: Mert Kaan �UKADAR,Zeynep SEYMAN,Mert TIDIN,Hayati TOZLU
rand("seed",219)
%R1,R3 ve Rx icin 10 ile 30 araliginda rastgele tam sayi atanmasi.
R1=randi([10 30]);
R3=randi([10 30]);
Rx=randi([10 30]);
Vs=30;
istenilen_hassasiyet = 0.00001;
%Fonksiyon parametreleri ve fonksiyon tanimlanir.
function f=VG(R1,R2,R3,Rx,Vs)
  f=((R2/(R1+R2))-(Rx/(R3+Rx)))*Vs;
endfunction
%R2'nin alt ve ust degerleri atanir.
%Atanan degerlerinin fonksiyon donutlerini alinir.
R2_alt=0;
f_R2_alt=VG(R1,R2_alt,R3,Rx,Vs);

R2_ust=50;
f_R2_ust=VG(R1,R2_ust,R3,Rx,Vs);
%Bisection metod uygulanir.
adim=1;
while(abs(R2_ust-R2_alt)>istenilen_hassasiyet)

R2=(R2_ust+R2_alt)/2;
f_R2=VG(R1,R2,R3,Rx,Vs);
%Ciktilari duzenli bir sekilde alabilmek icin parametreler derlenir.
printf("%2d: %9.6f  %10.5f | %9.6f  %10.5f | %9.6f  %10.5f\n",adim,R2_alt,f_R2_alt,R2,f_R2,R2_ust,f_R2_ust)
if(sign(f_R2) == sign(f_R2_alt))

R2_alt=R2;
f_R2_alt=f_R2;
else
R2_ust = R2;
f_R2_ust=f_R2;
endif
adim= adim+1;
endwhile

printf("Galvonometre volt'u: %5.5f \n R2'nin degeri:%d \n",VG(R1,R2,R3,Rx,Vs),R2)
%Akimlar ilgili denklemlerce hesaplanir.
I1=Vs/(R1+R2)
I3=(R1*I1)/R3
%Hesaplanan akimlar ile Rx'nin gercek degeri saptanir.
Rx_gercek=(I1*R2)/I3
Hassasiyet_saglaniyor_mu=abs(Rx_gercek-Rx)<1E-5

%10 ile 30 arasindaki R2 degerleri ile VG hesaplanir.
matrix=[];
matrix_R2=[];
%R2 degerleri ile VG degerleri matrislere atanir.
for i=10:1:30
  R2_degerleri=i;
  d=VG(R1,R2_degerleri,R3,Rx,Vs);
  matrix=[matrix, d];
  matrix_R2=[matrix_R2,R2_degerleri];
endfor
%VG=f(R2) grafigi cizdirilir.
plot(matrix_R2,matrix,"p-")
%Grafik duzenlemesi yapilir.
set(gca, "xaxislocation", "origin")
set(gca, "yaxislocation", "origin")
set(gca, "box", "off")
xlabel("R2 Degerleri (ohm)")
ylabel("Galvanometre Degerleri (V)")

%Bonus

