%Grup adi: Maxwell 
%Grup uyeleri: Mert Kaan CUKADAR, Hayati TOZLU, Zeynep SEYMAN, Mert TIDIN

%Temizlik yapalim.

clc
clear all
close all

%Riemann ust toplami yapilir.

%Once sol tarafi hesaplayalim.
x0=-5.0299; x1 = 5.1233; 
x = x0:0.05:x1;
m =  4.0934; n =  1.7692;
y_dogru = x.*m + n;
yp_parabol = x.^2+4*x-24;

%dogru icin belirli integral:
belirli_integral = ((x1^2)*m /2) + n*x1 - (x0^2 * m /2 + n*x0)  
  
%parabol icin belirli integral:
  
yp_parabol = x1.^3/3 + 2*x1^2 -24*x1 - x0.^3/3 + 2*x0^2 -24*x0

%belirli integrallerin fark?: 
aradaki_alan = yp_parabol - belirli_integral