%Grup adi: Maxwell 
%Grup uyeleri: Mert Kaan CUKADAR, Hayati TOZLU, Zeynep SEYMAN, Mert TIDIN


%temizlik i�imiz rahatlasin
clear;
close all;
clc;
%verileri matrise aktaralim
Veriler =  [
 -6,-21
 -5,-20
 -4,-16
 -3,-10
 -2, -7
 -1, -2
 0, 2
 1, 6
 2, 11
 3, 13
 4, 18
 5, 24
 6, 25]

 %veri sutunlari ayrilir
 a = Veriler(:,1);
 b = Veriler(:,2);
 
 %birinci grafik penceresi acilir. ilk grafik cizilir.
 figure(1)
 plot(a,b,"bo-");
 
 % verileri for dongusu i�in hazirliyoruz.
 N = rows(Veriler);
 A1 = A2 = A3 = B1 = B2 = 0;
 % Hatalar minimize edilidi.For dondugunde hesaplandi "row" sayisi kadar.
 for i = 1:N
   A1 = A1 + 2*a(i)^2;
    A2 = A2 + 2*a(i);
    A3 = A3 + 2;
    B1 = B1 + 2*a(i)*b(i);
    B2 = B2 + 2*b(i); 
 endfor
 
% mx + n doiru denlkleminin kat sayilarini buluyoruz ("m" egim),("n"oteleme). 
m = (B1 - (A2 * B2 / A3))  / (A1 - (A2^2 / A3));
n = (B2 - A2 * m) / A3; 

%Verilere en yakin doiru �izilir.
x = linspace(-6,6,13);
y = m.*x + n;


% lineer regrasyon yapilmii doiru  ikinci figure �izdirilir.
figure(2);
plot(x,y,"r-");

%ayni figur uzerine ikinci bir grafik �izilir.Daha okunur olmasi i�in hold on kulanilir.
hold on;
plot(a,b,"bx");


%----------------------------------Part2------------------------------

% parabol olusturulur.
XX = linspace(-6,6,13)
YY = XX.^2 + 4.*XX -24;
plot(XX,YY,"ko-")

%dikdortgen cizilir.
rectangle ("position",[-5.0299,-28.809,10.140,54])


% random ayaralari yapilir. Dikdortgenin koseleri belirlenir.
rand("seed",219);
maxY=25.191;minY=-28.809;maxX=5.1101;minX=-5.0299;

%dikdortgen icine random sayilar atanir.
sayilar1 = randomArray = minX + (maxX-minX)*rand([10000,2]);
sayilar2 = randomArray = minY + (maxY-minY)*rand([10000,2]);

%olusturdugumuz sayilari parabol ve dogru uzerindeki ordinatlari hesaplanir
noktalar(:,1) = sayilar1(:,1);
ydd =  noktalar(:,2) = sayilar2(:,1);
yd = noktalar(:,3) = noktalar(:,1) * m + n;
yp  =  noktalar(:,4) = noktalar(:,1).**2 + 4 * noktalar(:,1) - 24;

%filtre olusturalim.
filtre = (yd - ydd >= 0 & yp - ydd <= 0);


%ici ve disi tanimlayan matrisler atanir
inside =  []
insidey = []
outside = []
outsidey = []

%yaptigimiz filtrenin satir sayilari atanir.
satir_sayisi = rows(filtre(:,1))


%for dongusu ile filtrenin sagladigi kosullar matrislere yazilir. 
for i = 1:satir_sayisi
  if (filtre(i) == 1)
   inside = [inside , noktalar(i,1)];
   insidey = [insidey , noktalar(i,2)];
  endif  
  
  if (filtre(i) == 0)
   outside = [outside , noktalar(i,1)];
   outsidey = [outsidey, noktalar(i,2)];
   
  endif  
  
endfor


%noktalar plot araciligi ile 2. figure yazdirilir. 
plot(inside,insidey,"y.")
plot(outside,outsidey,"g.")
hold off

#alan hesaplamasi yapilir.
icli = length(inside);
disli = length(outside);

dikdortgen_alani = 10.140 * 54;
ucuncu_bolge_alani = dikdortgen_alani * (icli/(icli+disli))

%kaynakca:
%ttp://ocw.uci.edu/upload/files/mae10_w2011_lecture13.pdf
%doc.Dr.Orhan Gazi & Uzman doktor Kemal Catmakas Matlab Uygulamali sayisal sinyal isleme [58,61,81]
 
 
 