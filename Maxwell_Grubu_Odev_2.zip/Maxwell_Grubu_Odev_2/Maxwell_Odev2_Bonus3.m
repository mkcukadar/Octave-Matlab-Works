%Grup adi: Maxwell 
%Grup uyeleri: Mert Kaan CUKADAR, Hayati TOZLU, Zeynep SEYMAN, Mert TIDIN


%temizlik i�imiz rahatlasin
clear;
close all;
clc;
%verileri matrise aktaralim
Veriler =  [
 -6,-21
 -5,-20
 -4,-16
 -3,-10
 -2, -7
 -1, -2
 0, 2
 1, 6
 2, 11
 3, 13
 4, 18
 5, 24
 6, 25]

 %veri sutunlari ayrilir
 a = Veriler(:,1);
 b = Veriler(:,2);
 
 %birinci grafik penceresi acilir. ilk grafik cizilir.
 figure(1)
 plot(a,b,"bo-");
 
 % verileri for dongusu i�in hazirliyoruz.
 N = rows(Veriler);
 A1 = A2 = A3 = B1 = B2 = 0;
 % Hatalar minimize edilidi.For donguunde hesaplandi "row" sayisi kadar.
 for i = 1:N
   A1 = A1 + 2*a(i)^2;
    A2 = A2 + 2*a(i);
    A3 = A3 + 2;
    B1 = B1 + 2*a(i)*b(i);
    B2 = B2 + 2*b(i); 
 endfor
 
% mx + n doiru denlkleminin kat sayilarini buluyoruz ("m" egim),("n"oteleme). 
m = (B1 - (A2 * B2 / A3))  / (A1 - (A2^2 / A3));
n = (B2 - A2 * m) / A3; 

%Verilere en yakin doiru �izilir.
x = linspace(-6,6,13);
y = m.*x + n;


% lineer regrasyon yapilmii doiru  ikinci figure �izdirilir.
figure(2);
plot(x,y,"r-");

%ayni figur uzerine ikinci bir grafik �izilir.Daha okunur olmasi i�in hold on kulanilir.
hold on;
plot(a,b,"bx");


%----------------------------------Part2------------------------------

% parabol olusturulur.
XX = linspace(-6,6,13)
YY = XX.^2 + 4*XX -24;
plot(XX,YY,"ko-")


%bolgesel olarak yamugun kordinatlari belirlenir.
a = [-5.0299 -5.0299 5.1233 5.1233 -5.0299];
b = [-30 -18.82 22.741 -30 -30];
%yamuk cizdirilir.
plot(a,b,"b-")
% rand komutu ayi degerlerin alinmasi iciin seed iler yapilandirilir.
rand("seed",219);

%matris araliklari belirlenir ilk odevdeki kare matris alani degerlendirilir.
matris1 = (rand([10000,1]))*10.14 - 5.03;
matris2 = (rand([10000,1]))*52.6 - 30;

%dogru denklemi birinci matrise gore tekrar atanir.
dogru_denklemini = m.*matris1 + n;
%ayni islem iikinci matrise gore tekrar edilir. 
parabol_deklemi = matris1.^2 + 4*matris1 - 24;

% dogru denklemi uzerinde bulunan dotlar filtre ediilir.
filtre = (dogru_denklemini > matris2)

%filtre edilmis degerler satirlar matrisine toplanir.
satirlar = [1:10000](filtre);

%satirlar matrisinde filtre edilmis degerleri index olarak icindekiler matrislerine atanir.
disindakilerx = matris1(satirlar,:)
disindakilery = matris2(satirlar,:)

%benzer bir filtre parabol icin kullanilir.
inside_filter = (parabol_deklemi > matris2)

%satilarin boolean degerleri alinir.
satirlar2 = [1:10000](inside_filter);

%bu degerler ic degerler olarak matristen cekilip atatnir.
insidex = matris1(satirlar2,:);
insidey = matris2(satirlar2,:);



%dotlar grafik uzerinde gosterilir.
plot(disindakilerx,disindakilery,"g.")
plot(insidex,insidey,"b.")

%yamugun alani bilinen koordinatlar uzerinden hesaplanir.uzunluklar degiskenlere atanir.
yatay_uzunluk = 5.0299 + 5.1233
ust_taban = 30 + 18.82
alt_taban = 22.741 + 30

disindakiler = numel(disindakilerx)
icerdeki_noktalar_sayisi = numel(insidex)

ara_bolge_alan = icerdeki_noktalar_sayisi / (disindakiler + icerdeki_noktalar_sayisi) * (ust_taban + alt_taban) * yatay_uzunluk / 2

%ana odevde bulunan deger yamugun alanindan cikartilir ve parabolun alt alani saptanir. 


%kaynakca:
%ttp://ocw.uci.edu/upload/files/mae10_w2011_lecture13.pdf
%doc.Dr.Orhan Gazi & Uzman doktor Kemal Catmakas Matlab Uygulamali sayisal sinyal isleme [58,61,81]
 
 