%Grup adi: Maxwell 
%Grup uyeleri: Mert Kaan CUKADAR, Hayati TOZLU, Zeynep SEYMAN, Mert TIDIN


%temizlik i�imiz rahatlasin
clear;
close all;
clc;

%
m =  4.0934; n =  1.7692;
rand("seed",219)
x = 12*rand(10000)-6;

yd = m*x + n; %dogru denklemi
yp = x.^2+4*x-24; % Parabol denklemi

%Ortak cozum yapilir.
yp_eksi_yd = x.^2 + (4-4.0934)*x + (-24-1.7692);

%K�kler bulunur ve bir matrikste toplanir.
kokler(:,1) = roots([1 (4-4.0934) (-24-1.7692)]); %apsisler
kokler(:,2) = m*kokler(:,1) + n; %ordinatlar

kokler